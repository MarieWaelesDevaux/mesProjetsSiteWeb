#!/bin/bash

# Fonction pour afficher stderr en rouge
color_stderr() {
    while IFS= read -r line; do
        echo -e "\e[31m$line\e[0m" >&2
    done
}

# Définir les chemins vers les répertoires
# Compiler les classes du projet webcompresslib
javac -d "webcompresslib/bin" "webcompresslib/src/webcompresslib/"*.java
if [ $? -ne 0 ]; then
    echo "Erreur de compilation dans webcompresslib" >&2
    exit 1
fi

# Compiler les classes du projet webpagessaver en incluant le classpath de webcompresslib
javac -cp "webcompresslib/src" -d "webpagessaver/bin"  "webpagessaver/src/webpagessaver/"*.java
if [ $? -ne 0 ]; then
    echo "Erreur de compilation dans webpagessaver" >&2
    exit 1
fi

# Exécuter le programme webpagessaver.WebPagesSaver avec stderr en rouge
java -cp "webpagessaver/bin:webcompresslib/bin" "webpagessaver.WebPagesSaver" "$@" 2> >(color_stderr)

