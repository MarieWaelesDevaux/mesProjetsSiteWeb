package webcompresslib;

import java.util.Comparator;

public class NodeComparator implements Comparator<Noeud> {
    @Override
    public int compare(Noeud node1, Noeud node2) {
        // Comparaison des occurrences
        int occurrenceComparison = Integer.compare(node1.getPoids(), node2.getPoids());
        if (occurrenceComparison != 0) {
            // Si les occurrences sont différentes, retourner la comparaison des occurrences
            return occurrenceComparison;
        } else {
            // Si les occurrences sont égales, comparer les caractères
            if (node1.getNom() == null && node2.getNom() == null) {
    			throw new IllegalStateException("ERREURE : Comparaison de deux noeuds à caractères identiques).");
            } else {
                // comparer les caractères dans l'ordre lexicographique
                return node1.getNom().compareTo(node2.getNom());
            }
        }
    }
}