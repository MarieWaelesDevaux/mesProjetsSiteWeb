package webcompresslib;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeSet;

public class ArbreBinaire {
	/**
	* La classe ArbreBinaire implémente un arbre binaire strict,
	* généré à partir d'un texte, et servant de base au codage
	* de Huffman.
	* L'implémentation faite ici est récursive : chaque branche est elle-même 
	* un arbre binaire.
	*/
	// ATTRIBUTS :
	/**
    * Les branches de l'arbre binaire sont elles-mêmes des arbres binaire.
    * Comme l'arbre est strictement binaire, il peut y avoir soit deux branches,
    * soit aucune (en ce cas, l'arbre est composée juste d'une feuille).
	 */
	private ArbreBinaire[] branches;
	/**
	 * Le nœud stocke le poids total de l'arbre, et le plus petit caractère
     * (pour l'ordre lexicographique) parmi toutes ses feuilles.
	 */
	private Noeud noeud;
	
	
	
	// CONSTRUCTEURS :
	public ArbreBinaire(Noeud noeud) {
		/**
		 * Ce constructeur sert à créer un arbre constitué d'une seule feuille.
		 * @param noeud
		 */
		this.branches = new ArbreBinaire[0];
		this.noeud = noeud;
	}
	public ArbreBinaire(Noeud noeud, ArbreBinaire[] branches) {
		/**
		 * Ce constructeur crée un arbre avec 2 branches.
		 * @param noeud
		 * @param branches
		 */
		this.branches = branches;
		this.noeud = noeud;
	}
	public ArbreBinaire(String texte) {
		/**
		 * Ce constructeur génère l'arbre binaire de huffman à partir d'un texte.
		 * @param texte
		 */
		/*this.branches = new ArbreBinaire[0];
		this.noeud = new Noeud(texte.charAt(0), 0);*/
		ArbreBinaire arbreDeHuffman = getArbreDeHuffman(texte);
		branches = arbreDeHuffman.getBranches();
		noeud = arbreDeHuffman.getRacine();
		// Implémenter les Codes Binaires de chaques noeud descendant de l'arbre :
		implementCodseBinaireDesDescendants("");
	}
	
	// ACCESSEURS :
	public Noeud getRacine() {
		return noeud;
	}
	public ArbreBinaire[] getBranches() {
		return branches;
	}
	
	// AUTRES METHODES :
	
	// -----------------------------------------------------------------------------------
	// Methodes de constriction de l'arbre de huffman à partir d'un texte
	private static Map<Character, Integer> getDictionaireCharacterOccurrence(String texte) {
		/**
		 * Méthode de classe qui récupère le dictionaire des occurences de chaques caractère du texte
		 * @param texte
		 */
		Map<Character, Integer> dictionaireCharacterOccurrence = new HashMap<Character, Integer>();
		// POUR chaques caractères du texte :
		for (char c : texte.toCharArray()) {
			// Si le carractère est déjà apparu precedament dans le texte opservé
			// càd si le caractère est répertoriée et possède déjà une occurence dans le dictionnaire
			if(dictionaireCharacterOccurrence.containsKey(c)) {
				// incrémenter de un le nombre d'occurence du caractère opservé
				dictionaireCharacterOccurrence.put(c, dictionaireCharacterOccurrence.get(c)+1);
			}
			else {
				// répertorier le caractère opservé dans le dictionnaire avec une occurence
				dictionaireCharacterOccurrence.put(c, 1);
			}
		}
		return 	dictionaireCharacterOccurrence;
	}
	private static TreeSet<ArbreBinaire> getListArbresTries(String texte){
		/**
		 * Méthode de classe qui récupèrela liste des arbres à un seul noeud (feuilles) de tous les caractères du texte trié dans l'ordre de traitement du codage de huffman
		 * @param texte
		 */
		// CONVERTIR LA MAP EN LISTE ORDONNEE (qui se trie automatiquement) DE NOUEDS
		TreeSet<ArbreBinaire> listNoeudsTries = new TreeSet<ArbreBinaire>(new ArbreComparator());
		for (Entry<Character, Integer> tuple : getDictionaireCharacterOccurrence(texte).entrySet()) {
			listNoeudsTries.add(new ArbreBinaire(new Noeud(tuple.getKey(), tuple.getValue())));
		}
		return listNoeudsTries;
	}
	private static ArbreBinaire assemble2Arbres(ArbreBinaire arbre1, ArbreBinaire arbre2) {
		/**
		 * Méthode qui assemble deux arbres binaires selon l'ordre du codage de huffman (en créant le nouveau noeud racine correspondant
		 * @param arbre1
		 * @param arbre2
		 */
		Noeud laPlusPetiteRacine = arbre1.getRacine();
		Noeud laDiemePlusPetiteRacine = arbre2.getRacine();
		ArbreBinaire[] les2PlusPetitsArbres = {arbre1, arbre2};
		// si le caractère du plus petit noeud est lexicographiquement avant le caractère du second plus petit noeud :
		if(laPlusPetiteRacine.getNom().compareTo(laDiemePlusPetiteRacine.getNom())<0) {
			
			return new ArbreBinaire(new Noeud(laPlusPetiteRacine.getNom(), laPlusPetiteRacine.getPoids()+laDiemePlusPetiteRacine.getPoids()), les2PlusPetitsArbres);
		}
		else{
			return new ArbreBinaire(new Noeud(laDiemePlusPetiteRacine.getNom(), laPlusPetiteRacine.getPoids()+laDiemePlusPetiteRacine.getPoids()), les2PlusPetitsArbres);
		}
	}
	private static ArbreBinaire assembleNoeudsDeLArbre(TreeSet<ArbreBinaire> listArbresTries) {	
		/**
		 * Méthode qui assemble (selon l'ordre du codage de huffman) tous les arbres de la liste des arbres passé en paramettre
		 * @param listArbresTries
		 */
		// TANT QU'il ne reste pas plus qu'une unique racine :
		while(listArbresTries.size()!=1) {
			listArbresTries.add(assemble2Arbres(listArbresTries.pollFirst(), listArbresTries.pollFirst()));
		}		
		return listArbresTries.pollFirst();
	}
	private static ArbreBinaire getArbreDeHuffman(String texte) {	
		/**
		 * Méthode qui donne l'arbre de huffman à partir d'un texte
		 * @param texte
		 */
		return assembleNoeudsDeLArbre(getListArbresTries(texte));
	}
	
	private void implementCodseBinaireDesDescendants(String codeDuParent) {
		/**
		 * Méthode qui donne à chaques noeuds de cette arbre son code binaire
		 * @param codeDuParent
		 */
		if(branches.length==2) {
			branches[0].getRacine().setCodeBinaire(codeDuParent+"0");
			branches[0].implementCodseBinaireDesDescendants(codeDuParent+"0");
			branches[1].getRacine().setCodeBinaire(codeDuParent+"1");
			branches[1].implementCodseBinaireDesDescendants(codeDuParent+"1");
		}
	}
	
	// -----------------------------------------------------------------------------------
	// Méthode d'encodage
	// Methodes de répértoriation des code binaires des caractères dans un dictionaire
	private void addCodeBinaireDesDescendantsDansDico(HashMap<String, String> dictionaireDesCodesBinaire) {
		/**
		 * ajoute au dictionnaire d'encodage passé en paramettre, les noms et le code binaire de chaques noeuds de cet arbre.
		 * @return le dictionnaire d'encodage
		 */
		if(branches.length==2) {
			branches[0].addCodeBinaireDesDescendantsDansDico(dictionaireDesCodesBinaire);
			branches[1].addCodeBinaireDesDescendantsDansDico(dictionaireDesCodesBinaire);
		}
		else {
			dictionaireDesCodesBinaire.put(noeud.getNom(), noeud.getCodeBinaire());
		}
	}
	public HashMap<String, String> dictionnaireEncodage() {
		/**
		 * Donne le dictionnaire d'encodage correspondant à cet arbre binaire (codage de Huffman).
		 * @return le dictionnaire d'encodage
		 */
		HashMap<String, String> dictionaireDesCodesBinaire = new HashMap<String, String>();
		
		
		addCodeBinaireDesDescendantsDansDico(dictionaireDesCodesBinaire);
		
		return dictionaireDesCodesBinaire;
	}
	
	public String encode(String texte) {	
		/**
		 * @param texte à encoder
		 * @return chaine de caractère contenant :
		 * 		- tout d'abord le dictionnaire d'encodage
		 * 		- puis le texte encodé sous forme d'une chaîne de 0 et de 1.
		 */		
		// Optenir le dictionaire des code binaire de chaques caractères présent dans le texte :
		HashMap<String, String> dictionaireDesCodesBinaire = dictionnaireEncodage();
		String texteEncode = "";
		
		// insérer le dictionnaire d'encodage au début de la chaine de codée
		for (Entry<String, String> entry : dictionaireDesCodesBinaire.entrySet()) {
			texteEncode += entry.getKey() + entry.getValue() + "{";	
		}
		// supprimer le dernier '{' et le remvlacer par un '}' :
		texteEncode = texteEncode.substring(0, texteEncode.length()-1) + "}";
		
		// Encoder chaques carractères 1 à 1 :
		for (char c : texte.toCharArray()) {
			texteEncode += dictionaireDesCodesBinaire.get(c+"");	
		}
		
		return texteEncode;
	}
	
	// -----------------------------------------------------------------------------------
	// Methode de décodage
	public static String decode(String code) {
		/**
		 * @param chaine de caractère contenant :
		 * 		- tout d'abord le dictionnaire d'encodage
		 * 		- puis le texte encodé sous forme d'une chaîne de 0 et de 1.
		 * @return le texte décodé
		 */
		int i=0, j;
		char bit;
		HashMap<String, Character> dictionaireDesCodesBinaire = new HashMap<String, Character>();
		String codeDuCaractere;
		String texteDecode = "";
		
		// RECUPERATION DU DICTIONNAIRE D'ENCODAGE :
		do{
			j = i +1;
			while(code.charAt(j)!='{' && code.charAt(j)!='}'){
				j++;
			}
			dictionaireDesCodesBinaire.put((String) code.substring(i+1, j), code.charAt(i));
			i = j +1;
		}
		while(code.charAt(i-1)!='}');
		
		// DECODAGE
		// Tant qu'il reste des caractères à décoder :
		while(i<code.length()-1) {
			bit = code.charAt(i);
			codeDuCaractere = "" + bit;
			// tant que nous n'avons pas le codage d'un caractère complet :
			while(!dictionaireDesCodesBinaire.containsKey(codeDuCaractere) && (bit = code.charAt(i+1)) != '/') {
				i++;
				codeDuCaractere += bit;
				//System.out.println("**" + codeDuCaractere);
			}
			if(bit != '/') {
				// ajouter les caractère décodé à la chaine du texte décodé
				texteDecode += dictionaireDesCodesBinaire.get(codeDuCaractere);	
				//System.err.println(dictionaireDesCodesBinaire.get(codeDuCaractere));
			}
			i++;
		}
		System.out.println(texteDecode);

		return texteDecode;
	}



}