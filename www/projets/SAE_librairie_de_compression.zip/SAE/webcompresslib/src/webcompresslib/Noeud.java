package webcompresslib;

public class Noeud {
	// ATTRIBUTS :
	private String nom = "";
	private String codeBinaire = "";
	private int poids = 0;
	
	// CONSTRUCTEURS :
	public Noeud(String nom, int poids) {
		this.nom = nom;
		this.poids = poids;
	}
	public Noeud(Character nom, int poids) {
		this.nom = nom.toString();
		this.poids = poids;
	}
	
	// ACCESSEURS :
	public String getNom() {
		return nom;
	}
	public int getPoids() {
		return poids;
	}
	public String getCodeBinaire() {
		return codeBinaire;
	}
	
	
	// SETTEURS :
	public void setCodeBinaire(String codeBinaire) {
		this.codeBinaire = codeBinaire;
	}
}
