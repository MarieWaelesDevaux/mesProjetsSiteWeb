package webcompresslib;

import java.util.Comparator;

public class ArbreComparator  implements Comparator<ArbreBinaire> {
    @Override
    public int compare(ArbreBinaire arbre1, ArbreBinaire arbre2) {
        return (new NodeComparator()).compare(arbre1.getRacine(),arbre2.getRacine());
    }
}