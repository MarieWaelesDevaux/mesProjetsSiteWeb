package webpagessaver;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.stream.Stream;

import webcompresslib.ArbreBinaire;

public class FichierCompresse {
	// ATTRIBUTS :
	private Path chemin = null;
	private String contenu = "";
	private String contenuDecompresse;
	
	// CONSTRUCTEUR :
	protected FichierCompresse(Path chemin) throws IOException {
		this.chemin = chemin;
		this.recupereContenu();
		// décompresser le contenu
		this.contenuDecompresse = ArbreBinaire.decode(this.contenu);
	}
	
	public String getContenuDecompresse() {
		return this.contenuDecompresse;
	}

	
	// METHODES :
	public static void decompresseArborescenceRecursivement(Path cheminDuFichierADecompresser, File dossierDeDecompression) throws IOException {
		/**
    	 * Méthode qui décompresse récursivement tous le contenu du dossier dont le chemin est passé en paramettre dans le dossier passé en paramettres
    	 * @param cheminDuFichierADecompresser:Path -> chemin apsolu du fichier à décompresser
    	 * @param dossierDeDecompression:File -> dossier dans lequel il faut enregistré le contenu décompréssé
    	 */
		// SI c'est un répertoire
        if (Files.isDirectory(cheminDuFichierADecompresser)) {
        	System.out.println("***"+ cheminDuFichierADecompresser);
            File repertoireACreerDansDossierDeDecompression = new File(dossierDeDecompression, cheminDuFichierADecompresser.getFileName().toString());
            // Si il faut le créer
            if (!repertoireACreerDansDossierDeDecompression.exists()) {
                if (repertoireACreerDansDossierDeDecompression.mkdir()) {
                    System.out.println("Dossier \"" + repertoireACreerDansDossierDeDecompression.getAbsolutePath() + "\" crée.");
                }
                else {
                    System.err.println("Échec de la création du dossier \"" + repertoireACreerDansDossierDeDecompression.getAbsolutePath() + "\".");
                }
            }
            // Décompresser recursivement les fichiers (fichiers ou repertoires) qu'il contien
            try (Stream<Path> cheminsEnfants = Files.list(cheminDuFichierADecompresser)) {
                cheminsEnfants.forEach(cheminEnfant -> {
                    try {
                        decompresseArborescenceRecursivement(cheminEnfant, repertoireACreerDansDossierDeDecompression);
                    } catch (IOException e) {
                        System.err.println("Erreur lors de la décompression du fichier : " + e.getMessage());
                    }
                });
            }
        }
        else {
        	// SI c'est une image
            if (FichierCompresse.estImage(cheminDuFichierADecompresser)) {
                String nomDuFichier = cheminDuFichierADecompresser.getFileName().toString();
                File fichierDestination = new File(dossierDeDecompression, nomDuFichier);
                try {
                    Files.copy(cheminDuFichierADecompresser, fichierDestination.toPath());
                    System.out.println("Copie de l'image : " + nomDuFichier);
                } catch (IOException e) {
                    System.err.println("Erreur lors de la copie de l'image : " + e.getMessage());
                }
            }
            // SI c'est un fichier texte à decoder
            else {
            	System.out.println("******"+ cheminDuFichierADecompresser);
                FichierCompresse fichier = new FichierCompresse(cheminDuFichierADecompresser);
                String nomDuFichierSansExtentionDeCompression = cheminDuFichierADecompresser.getFileName().toString();
                int iDeLExtention = nomDuFichierSansExtentionDeCompression.lastIndexOf(".");
                
                // récupérer le nom sans l'extantion "compresse.txt"
                iDeLExtention = nomDuFichierSansExtentionDeCompression.lastIndexOf(".", iDeLExtention - 1);
                nomDuFichierSansExtentionDeCompression = nomDuFichierSansExtentionDeCompression.substring(0, iDeLExtention);
                // créer le fichier décompressé
                fichier.creerFichierDecompresse(dossierDeDecompression.toString(), nomDuFichierSansExtentionDeCompression);
            }
        }
    }

	private static boolean estImage(Path fichier) {
    	/**
    	 * Méthode qui indique si un chemin mène vers une image
    	 * @return :boolean -> true si c'est un chemin qui mène vers une image
    	 */	
        String nomDuFichier = fichier.getFileName().toString().toLowerCase();
        ArrayList<String> extensionsImages = new ArrayList<String>(Arrays.asList(".jpg", ".jpeg", ".png", ".gif", ".bmp", ".svg"));
        return extensionsImages.stream().anyMatch(nomDuFichier::endsWith);
    }
	
    private void recupereContenu() {
    	/**
    	 * Méthode qui récupère le contenu de la page HTLM dont le lien est fourni en paramettres
    	 */
    	// TODO : Régler le problème des caractère mal lues tel que à et é

    	// Variables pour la lecture du dictionaire
    	FileReader fichierPourDictionnaire;
        BufferedReader reader;
        char caracterePrecedent = ' ';
        char caractere = ' ';
        int charInt;
    	// Variables pour la lecture du texte encodé
        FileInputStream fichierPourBits;
        BufferedInputStream  readerPourBits;
    	int octet;
    	
    	// lecture du dictionaire
        try {
        	fichierPourDictionnaire = new FileReader(this.chemin.toString());
        	reader = new BufferedReader(fichierPourDictionnaire);
        	// Lire le contenu cdu dictionnaire,aractère par caractère et l'ajoutter au dictionnaire 
        	// tant que ce n'est pas la fin du document ET
        	// que l'on ne rencontre pas une suite de "0}" ou "1}" qui indiquerait la fin du dictionnaire (il ne faut pas seullement vériffier si on rencontre le catactère '}' tout seul car celui ci pourrait apparaitre à la suite d'un '{' pour indiquer le code binaire du caractère '}'
            while ((charInt = reader.read()) != -1) {
            	// si caractère : } rencontré
            	if((caractere=(char)charInt)=='}') {
            		System.err.println(caracterePrecedent);
            		// si c'est le carractère de fin (et non pas la clef } du dictionnaire de décodage)
	            	if((caracterePrecedent=='0'||caracterePrecedent=='1')) {
	            		System.err.println("ah");
	            		break;
	            	}
            	}
            	caracterePrecedent = caractere;
            	this.contenu+=caractere;
            }
            this.contenu+=caractere; // pour ajoutter le '}'
            reader.close();
            fichierPourDictionnaire.close();
        }
        catch (IOException e) {
            System.out.println("Erreur de lecture dans le fichier \"" + this.chemin.toString() + "\" : " + e.getMessage());
        }
        // lecture du texte encodé
        try {
        	fichierPourBits = new FileInputStream(this.chemin.toString());
        	readerPourBits = new BufferedInputStream(fichierPourBits);
        	
        	// Récupérer le dictionnaire jusqu'à '}'
        	caracterePrecedent = ' ';
            while ((octet = readerPourBits.read()) != -1) {
            	// si caractère : } rencontré
            	if((caractere=(char)octet)=='}') {
            		// si c'est le carractère de fin (et non pas la clef } du dictionnaire de décodage)
	            	if(((caracterePrecedent=='0'||caracterePrecedent=='1'))) {
	            		break;
	            	}
            	}
            	caracterePrecedent = caractere;
            }
        	// Lire le contenu octet par octet et l'ajoutter à la variable contenu
            while ((octet = readerPourBits.read()) != -1) {
            	// Convertir l'octet en une chaîne de bits de 8 caractères et l'ajoutter au contenu
            	this.contenu += String.format("%8s", Integer.toBinaryString(octet & 0xFF)).replace(' ', '0');
            }
            readerPourBits.close();
            fichierPourBits.close();
            
        }
        catch (IOException e) {
            System.out.println("Erreur de lecture dans le fichier \"" + this.chemin.toString() + "\" : " + e.getMessage());
        }
        this.contenu += '/';
        System.out.println("\n\n---------------------------------\n\n\n");
        System.out.println(this.contenu);
        System.out.println("\n\n---------------------------------\n\n\n");
        
        // Si le fichier est vide
        if (contenu.isEmpty()) {
            System.err.println("Erreur: le fichier HTML est vide.");
        }
    }
    
	public void creerFichierDecompresse(String repertoireDeDestination, String nomDuFichier) throws IOException {
    	/**
    	 * Méthode qui créer un fichier du nom passé en paramettre et écrit le contenu décompressé de l'instance de Fichier à l'intérrieure
    	 * @param repertoireDeDestination:String -> chemin apsolu du repertoire dans lequel il faut créer le fichier
    	 * @param nomDuFichier:String -> nom du fichier à créer
    	 */
		// créer le fichier :
    	File fichier = new File(repertoireDeDestination, nomDuFichier);
    	FileWriter fichierPourEcriture = null;
    	BufferedWriter writer = null;
    	
        try {
        	// Ouverir le fichier pour l'écriture
        	fichierPourEcriture = new FileWriter(fichier);
            // ouvrir la mémoire tampon d'écriture du fichier
            writer = new BufferedWriter(fichierPourEcriture);
            // écrir le contenu rentré en paramettre dans le fichier
            writer.write(this.contenuDecompresse);
            // fermer le fichier et la mémoire tampon
            writer.close();
            fichierPourEcriture.close();
        }
        catch (IOException e) {
            System.err.println("Erreur d'écriture dans le fichier \"" + fichier + "\" : " + e.getMessage());
        }
    }
}
