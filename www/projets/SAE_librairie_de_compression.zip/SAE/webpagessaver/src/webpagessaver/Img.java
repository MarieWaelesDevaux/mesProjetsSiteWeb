package webpagessaver;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Img {	
    public static void telecharge(URL baseUrl, String repertoireDeDestination, String adresseImage) throws IOException {
    	/**
		 * Methode qui crée l'arborescence de l'adresse passé en paramettre si celle si n'existe pas et télécharge l'immage
		 * @param adresse:String -> adresse de l'arborescence à créer
		 */
    	URL url = baseUrl;
    	InputStream fluxDEntreeSOctets = null;
    	Path cheminFichier = null;
    	
    	if(adresseImage.startsWith("/", 0)){
    		url = new URL(baseUrl.getHost());
    	}
        url = new URL(url, adresseImage);
        // Créer le chemin complet du fichier de destination
        cheminFichier = Paths.get(repertoireDeDestination, adresseImage);

        // Récupérer l'arborescence de répertoires
        Arborescence.creer(repertoireDeDestination, adresseImage);

        // Télécharger les images
        if(!Files.exists(cheminFichier)) {
	        try {
	        	fluxDEntreeSOctets = url.openStream();
	            Files.copy(fluxDEntreeSOctets, cheminFichier);
	            System.out.println("Image téléchargée : " + adresseImage);
	        } catch (IOException e) {
	            e.printStackTrace();
	            System.err.println("Erreur lors du téléchargement de l'image : " + adresseImage);
	        }
        }
        else {
			System.out.println("Image déjà existante : " + adresseImage);
		}
    }
}
