package webpagessaver;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Arborescence {
	public static File getReprtoire(String nomRep) {
		/**
		 * Methode qui créé le dossier nomRep à la racine du projet (c'est à dire au même endroit que bin et src) si celui-ci n'existe pas déjà et retourne celuici
		 * @param nomRep:String -> "cache" ou "telechargement_decompresse" (nom du répertoire à créer et/ou récupérer à la racine du projet)
		 * @return :File -> le dossier demmandé qui se trouve à la racine du projet
		 */
		Path cheminRelatifParentDuRepertoireCourant = null;
		String cheminApsoluParentDuRepertoireCourant;
		File dossierDemmande = null;
		
		// Récupération du chemin apsolu de la racine du projet webpagessaver :
		// recuperation du chemin relatif du repertoire courrant ("/webpagessaver")
		cheminRelatifParentDuRepertoireCourant = Paths.get("");
		// recuperation du chemin apsolu du repertoire courrant ("/webpagessaver")
		cheminApsoluParentDuRepertoireCourant = cheminRelatifParentDuRepertoireCourant.resolve("webpagessaver").toAbsolutePath().toString();
		
		// Création du dossier "cache" ou "telechargement_decompresse" dans le repertoire panate du repertoire courrant ("/bin") dont dans le même repertoire que "/src"
		dossierDemmande = new File(cheminApsoluParentDuRepertoireCourant, nomRep);
		
		// création du répertoire ci celui-ci n'existe pas déjà
		if (!dossierDemmande.exists()) {
            if (dossierDemmande.mkdir()) {
                System.out.println("Dossier \"" + dossierDemmande.getAbsolutePath() +"\" crée.");
            } else {
                System.err.println("Échec de la création du dossier \"" + dossierDemmande.getAbsolutePath() +"\".");
            }
        }
		return dossierDemmande;
	}
	
	public static String creerAreborescenceRacineDuTelechargement(String lienEntre) {
		/**
		 * Methode qui crée le dossier qui va contenir le fichie qui vas être téléchargé à l'aide de l'arborescence passé en paramettre
		 * @return :String -> chemin apsolu du dossier de téléchargement
		 */
		File dossierCache = getReprtoire("cache");
		File dossierDeTelechargement;
        

        dossierDeTelechargement = new File(dossierCache, lienEntre);

        // créer le dossier
        if(dossierDeTelechargement.exists() && dossierDeTelechargement.isDirectory()) {
        	System.out.println("Le dossier \"" + dossierDeTelechargement.getAbsolutePath() + "\" existe déjà.");
        }
        else if (dossierDeTelechargement.mkdir()) {
            System.out.println("Dossier \"" + dossierDeTelechargement.getAbsolutePath() + "\" créé.");
        }
        else {
            System.err.println("Échec de la création du dossier : " + dossierDeTelechargement.getAbsolutePath());
        }
        
        return dossierDeTelechargement.getAbsolutePath();
	}
	
	public static void creer(String repertoireDeDestination, String adresse) {
		/**
		 * Methode qui crée l'arborescence de l'adresse passé en paramettre si celle si n'existe pas
		 * @param adresse:String -> adresse de l'arborescence à créer
		 */
		String adresseInterneComplette = repertoireDeDestination + File.separator + adresse;
    	String repertoireParcouru;
    	File rep = null;
    	int iSeparateurAvecFichierSuivant = adresseInterneComplette.indexOf(File.separator, 2);
    	// Parcourir le chemin du fichier de gauche à droite, du répertoire racine jusqu'au répertoire cible
    	while (iSeparateurAvecFichierSuivant != -1) {
    		repertoireParcouru = adresseInterneComplette.substring(0, iSeparateurAvecFichierSuivant);
    	    rep = new File(repertoireParcouru);
    	    // Si le répertoire n'existe pas, le créer
    	    if (!rep.exists()) {
    	        if (rep.mkdirs()) {
    	            System.out.println("Répertoire créé : " + rep.getAbsolutePath());
    	        }
    	        else {
    	            System.err.println("Échec de la création du répertoire : " + rep.getAbsolutePath());
    	            return;
    	        }
    	    }
    	    // Trouver l'index du prochain séparateur
    	    iSeparateurAvecFichierSuivant = adresseInterneComplette.indexOf(File.separator, iSeparateurAvecFichierSuivant + 1);
    	}   
	}
}
