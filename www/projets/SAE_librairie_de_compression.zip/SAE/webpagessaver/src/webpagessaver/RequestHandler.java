package webpagessaver;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URI;
import java.net.URLDecoder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import com.sun.net.httpserver.HttpExchange;

class RequestHandler implements Runnable {
	/**
	 * Classe qui traite les requettes recues par le serveur
	 */
    private HttpExchange messageRecu;
    private WebPagesSaver webPagesSaver;

    public RequestHandler(HttpExchange messageRecu, WebPagesSaver webPagesSaver) {
        this.messageRecu = messageRecu;
        this.webPagesSaver = webPagesSaver;
    }

    @Override
    public void run() {
        try {
        	URI requette = messageRecu.getRequestURI();
        	System.err.println(messageRecu.getRequestURI());
            byte[] response = "Requette non reconnue".getBytes();
            if (requette != null) {
                String cheminRequette = requette.getPath(); // (correspond à "/add, /stop , /list, ...)
                String contenuRequetteCADurl = requette.getQuery(); // seullement itulie pour add, remove et view (correpond à "url=http...") ou "/nom_de_fichier_a_ouvrir_en_decompresse"
                switch (cheminRequette) {
                    case "/help":
                    	response = WebPagesSaver.help().getBytes();
                        break;
                    case "/test":
                        response = webPagesSaver.test().getBytes();
                        break;
                    case "/stop":
                        response = "Serveur fermé".getBytes();
                        // le serveur seras dermé plus tard de sorte à ce que le message et la page puissent s'afficher correctement sans problème de connection au serveur qui serait déjà stoppé
                        break;
                	case "/add":
                        if (contenuRequetteCADurl != null && contenuRequetteCADurl.startsWith("url=")) {
                            String url = contenuRequetteCADurl.substring(4);
                            response = "add".getBytes();
                            webPagesSaver.add(URLDecoder.decode(url, "UTF-8"));
                        } else {
                            response = "URL manquant".getBytes();
                        }
                        break;
                    case "/remove":
                        if (contenuRequetteCADurl != null && contenuRequetteCADurl.startsWith("url=")) {
                            String url = contenuRequetteCADurl.substring(4);
                            response = "remove".getBytes();
                            webPagesSaver.remove(URLDecoder.decode(url, "UTF-8"));
                        }
                        else {
                            response = "URL manquant".getBytes();
                        }
                        break;
                    case "/" :
                    	response = webPagesSaver.acceuil().getBytes();
                        // Indiquer le type MIME du fichier (donc html)
                    	messageRecu.getResponseHeaders().set("Content-Type", "text/html");
                        break;
                    case "/list":
                        response = webPagesSaver.list().getBytes();
                        // Indiquer le type MIME du fichier (donc html)
                        messageRecu.getResponseHeaders().set("Content-Type", "text/html");
                        break;
                    case "/view":
                    	if (contenuRequetteCADurl != null && contenuRequetteCADurl.startsWith("url=")) {
                    		// retirer la partie "url="
                            String chemin = contenuRequetteCADurl.substring(4);
                            // retirer la partie protocole de l'url (par exemple "https://")
                            chemin = chemin.replaceFirst("^[a-zA-Z][a-zA-Z0-9+.-]*:(//)?", "");
                            response = ("view\nAFFICHAGE DE LA PAGE WEB : " + chemin).getBytes();
                            // ouvrir la page web à afficher dans une nouvelle fenetre
                            webPagesSaver.view(chemin);
                        } else {
                            response = "URL manquant".getBytes();
                        }
                        break;
                    default : // pour tout ce qui est ouverture de fichiers avec leurs chemin (http:///localhost:PORT/chemin_fichier_decompresse)
                    	System.out.println("Lecture de : " + requette);
                    	boolean estCompresse = true;
                    	Path cheminApsolutFichierLocal= Paths.get(Arborescence.getReprtoire("cache") + cheminRequette);
                    	// Si le fichier recherché n'est pas un fichier compressé (exemple image) :
                    	if(!cheminRequette.contains(".compresse.bin")) {
                    		if(Files.exists(cheminApsolutFichierLocal)) {
                    			// si c'est une image ou un fichier quelconque qui n'a pas été compréssé
                        		if(!Files.isDirectory(cheminApsolutFichierLocal)) {
                        			estCompresse = false;
                        		}
                        		//si c'est la racine d'un site internet et que par conséqauen le index.html n'est pas indiqué
                        		else {
                        			cheminRequette += "/index.html.compresse.bin";
                        		}
                        	}
                    		// si c'est un fichier qui a été téléchargé compréssé (et donc qui en locale contien l'extention .compresse.bin)
                        	else {
                        		cheminRequette += ".compresse.bin";
                        	}
                    		
                    	}
                        cheminApsolutFichierLocal = Paths.get(Arborescence.getReprtoire("cache") + cheminRequette);

                        // Vérification de l'existence du fichier
                        if (Files.exists(cheminApsolutFichierLocal) && !Files.isDirectory(cheminApsolutFichierLocal)) {
                        	Path cheminSansLExtentionDeCompression = Paths.get(cheminApsolutFichierLocal.toString().replace(".compresse.bin", ""));
                            // Récupération du type MIME du fichier
                            String contentType = Files.probeContentType(cheminSansLExtentionDeCompression);
                            // Lecture du contenu du fichier
                            if(estCompresse) {
                            	FichierCompresse fichier = new FichierCompresse(cheminApsolutFichierLocal);
                            	response = fichier.getContenuDecompresse().getBytes();
                            }
                            else {
                            	response = Files.readAllBytes(cheminApsolutFichierLocal);
                            }
                            // Indiquer le MIME du fichier envoyé (html, css, imgae, ...)
                            messageRecu.getResponseHeaders().set("Content-Type", contentType);
                        } else {
                            // Si le fichier demandé n'existe pas, renvoyer une réponse 404
                        	messageRecu.sendResponseHeaders(404, 0);
                        	messageRecu.getResponseBody().close();
                        }

                }
            }
            messageRecu.sendResponseHeaders(200, response.length);
            OutputStream outputStream = messageRecu.getResponseBody();
            outputStream.write(response);
            outputStream.close();
            // fermer le serveur si besoin seullement après l'affichage de la page pour ne pas que la connection à cette page crée une erreur car le serveur serait déjà fermé
            if(requette.getPath().equals("/stop")) {
            	webPagesSaver.stop();
            }
            
        } catch (IOException e) {
        	System.err.println("requette introuvable : \"" + messageRecu.getRequestURI()+ "\"");
        }
    }

}