package webpagessaver;

import java.awt.Desktop;
import java.io.*;
import java.net.*;
import java.util.ArrayList;
import com.sun.net.httpserver.HttpServer;


public class WebPagesSaver {
	// ATTRIBUTS :
	private HttpServer server = null;
    private boolean serveurEnTrainDeTourner;
    private final static int PORT = 2025;

    // CONSTRUCTEUR :
    public WebPagesSaver() {
        serveurEnTrainDeTourner = false;
    }

    // MAIN :
    public static void main(String[] args) throws IOException {
        String requette = "help";
        WebPagesSaver serveur = new WebPagesSaver();
        serveur.start();

        // SI la commande est correctement formée :
        if (args.length == 0) {
        	requette = "";
        }
        else if (args.length == 2 && (args[0].equals("add") || args[0].equals("remove") || args[0].equals("view"))) {
        	requette = args[0] + "?url=" + URLEncoder.encode(args[1], "UTF-8");
        }
        else if (args.length == 1 && args[0].equals("list")) {
        	requette = args[0];
        }// (sinon la requette garde la valeur "help"
        
        // ouverir automatiquement dans le navigateur par défaut, de la page web correspondante à la requette de la commande entrée 
        String uriString = "http://localhost:" + PORT + "/" + requette;
        try {
            Desktop desktop = Desktop.getDesktop();
            desktop.browse(new URI(uriString));
        } catch (IOException | URISyntaxException e) {
            e.printStackTrace();
        }
    }


    
    
    
    // METHODES DE CONTROLE DU WEBPAGESSAVER
    public static String help() {
        System.out.println("usage: webpagesaver {add,remove,list,view}");
        return "usage: webpagesaver {add,remove,list,view}";
    }
    public void start() throws IOException {
    	if (!serveurEnTrainDeTourner) {
            server = HttpServer.create(new InetSocketAddress(PORT), 0);
            serveurEnTrainDeTourner = true;
            System.out.println("Serveur lancé sur le port : " + PORT + ".");

            server.createContext("/", new PageHandler(this));
            server.createContext("/add", new PageHandler(this));
            server.createContext("/remove", new PageHandler(this));
            server.createContext("/list", new PageHandler(this));
            server.createContext("/view", new PageHandler(this));
            server.createContext("/stop", new PageHandler(this));
            server.createContext("/test", new PageHandler(this));
            server.createContext("/help", new PageHandler(this));

            server.setExecutor(null); // creates a default executor
            server.start();
        } else {
            System.err.println("Un serveur tourne déjà sur le port : " + PORT + ".");
        }
    }
    public String test() {
        return serveurEnTrainDeTourner ? "OK" : "X";
    }
    public void stop() {
        // fermeture du serveur
		server.stop(0);
		serveurEnTrainDeTourner = false;
		System.out.println("Serveur fermé.");
    }

    // METHODE DE REQUETTES A WEBPAGESSAVER
    // _______________________________________________________________________________________________________________
    // acceuil
    // _______________________________________________________________________________________________________________
    public String acceuil() {
    	/**
    	 * Methode qui crée le contenu de la page d'acceuil html du webpagessaver
    	 * @return String =>le contenu de la page d'acceuil html
    	 */
    	System.out.println("methode acceuil");
        // Génération du contenu de la page HTML
		String contenuPageListHtml = "<!DOCTYPE html>\n"
				+ "<html lang=\"fr\">\n"
				+ "<head>\n"
				+ "    <title>Redirection par URL dynamique</title>\n"
				+ "    <meta charset=\"utf-8\">\n"
				+ "    <style>\n"
				+ "        body {\n"
				+ "            min-height: 100vh;\n"
				+ "            display: flex;\n"
				+ "            flex-direction: column;\n"
				+ "            justify-content: center;\n"
				+ "            align-items: center;\n"
				+ "            font-family: sans-serif;\n"
				+ "            font-size: 1.4rem;\n"
				+ "            color: rgb(30, 0, 85);\n"
				+ "            background: linear-gradient(120deg, rgb(100, 17, 209), rgb(255, 0, 0));\n"
				+ "        }\n"
				+ "\n"
				+ "        header {\n"
				+ "            display: inline-block;\n"
				+ "            max-width: 40rem;\n"
				+ "            margin: 4rem auto;\n"
				+ "            font-size: 3rem;\n"
				+ "            color: hsl(0deg 100% 95%);\n"
				+ "            text-align: center;\n"
				+ "        }\n"
				+ "\n"
				+ "        h1 {\n"
				+ "            line-height: 4.7rem;\n"
				+ "            margin: 0;\n"
				+ "        }\n"
				+ "\n"
				+ "        h2 {\n"
				+ "            display: inline-block;\n"
				+ "            padding: 0.5rem;\n"
				+ "            margin: 0;\n"
				+ "            font-size: 0.5em;\n"
				+ "            color: rgb(75, 0, 0);\n"
				+ "            background: rgba(255, 255, 255, 0.4);\n"
				+ "            border-radius: 10px;\n"
				+ "        }\n"
				+ "\n"
				+ "        main {\n"
				+ "            text-align: center;\n"
				+ "            margin: 2rem;\n"
				+ "        }\n"
				+ "\n"
				+ "        .input-group {\n"
				+ "            display: inline-block;\n"
				+ "            vertical-align: top;\n"
				+ "            margin: 1rem;\n"
				+ "        }\n"
				+ "\n"
				+ "        input {\n"
				+ "            padding: 0.5rem;\n"
				+ "            font-size: 1.2rem;\n"
				+ "            background-image: linear-gradient(to top left, rgb(187, 135, 255), rgb(255, 255, 255));\n"
				+ "            border: 1px solid hsl(260deg 100% 95%);\n"
				+ "            border-radius: 0.3rem;\n"
				+ "            margin-bottom: 0.5rem;\n"
				+ "            width: 30rem; /* Largeur ajustable selon votre préférence */\n"
				+ "        }\n"
				+ "\n"
				+ "        button, a {\n"
				+ "            padding: 1rem;\n"
				+ "            font-size: 1.2rem;\n"
				+ "            font-weight: bold;\n"
				+ "            color: white;\n"
				+ "            background-color: rgb(100, 17, 209);\n"
				+ "            border: none;\n"
				+ "            border-radius: 0.3rem;\n"
				+ "            cursor: pointer;\n"
				+ "            text-decoration: none;\n"
				+ "            display: block; /* Pour que le bouton soit sur une nouvelle ligne */\n"
				+ "            width: 100%; /* Remplit la largeur de son contenant */\n"
				+ "        }\n"
				+ "\n"
				+ "        button:hover, a:hover {\n"
				+ "            background-color: rgb(80, 14, 170);\n"
				+ "        }\n"
				+ "\n"
				+ "        a {\n"
				+ "            margin: 1rem;\n"
				+ "            width: calc(100% - 4rem); /* Calcul pour ajuster la largeur */\n"
				+ "            text-align: center; /* Centrage du lien \"list\" */\n"
				+ "        }\n"
				+ "    </style>\n"
				+ "</head>\n"
				+ "<body>\n"
				+ "    <header>\n"
				+ "        <h1>Web Page Saver</h1>\n"
				+ "        <h2>compression de fichiers</h2>\n"
				+ "    </header>\n"
				+ "    <main>\n"
				+ "        <div class=\"input-group\">\n"
				+ "            <input type=\"text\" id=\"add_url_input\" placeholder=\"Entrez le chemin\">\n"
				+ "            <button onclick=\"add()\">add</button>\n"
				+ "        </div>\n"
				+ "        <div class=\"input-group\">\n"
				+ "            <input type=\"text\" id=\"view_url_input\" placeholder=\"Entrez le chemin\">\n"
				+ "            <button onclick=\"view()\">view</button>\n"
				+ "        </div>\n"
				+ "        <div class=\"input-group\">\n"
				+ "            <input type=\"text\" id=\"remove_url_input\" placeholder=\"Entrez le chemin\">\n"
				+ "            <button onclick=\"remove()\">remove</button>\n"
				+ "        </div>\n"
				+ "        <a href=\"http://localhost:"+PORT+"/list\">list</a>\n"
				+ "    </main>\n"
				+ "\n"
				+ "    <script>\n"
				+ "        function add() {\n"
				+ "            var input = document.getElementById('add_url_input').value;\n"
				+ "            var baseUrl = 'http://localhost:"+PORT+"/add?url=';\n"
				+ "            var fullUrl = baseUrl + input;\n"
				+ "            window.location.href = fullUrl;\n"
				+ "        }\n"
				+ "        function view() {\n"
				+ "            var input = document.getElementById('view_url_input').value;\n"
				+ "            var baseUrl = 'http://localhost:"+PORT+"/view?url=';\n"
				+ "            var fullUrl = baseUrl + input;\n"
				+ "            window.location.href = fullUrl;\n"
				+ "        }\n"
				+ "        function remove() {\n"
				+ "            var input = document.getElementById('remove_url_input').value;\n"
				+ "            var baseUrl = 'http://localhost:"+PORT+"/remove?url=';\n"
				+ "            var fullUrl = baseUrl + input;\n"
				+ "            window.location.href = fullUrl;\n"
				+ "        }\n"
				+ "    </script>\n"
				+ "</body>\n"
				+ "</html>\n"
				+ "";

        return contenuPageListHtml;
    }
    // _______________________________________________________________________________________________________________
    // add
    // _______________________________________________________________________________________________________________
    public void add(String urlTextPageInternetATelecharger) throws IOException {
    	/**
    	 * Methode qui prends en paramettre l'url d'une page internet et la télécharge en la compressant
    	 * @param lienEntre:String => url de la page internet à télécharger et compresser
    	 */
    	System.out.println("methode add");

    	// DECLARATION DES VARIABLES -------------
		URL urlPageInternetATelecharger = new URL(urlTextPageInternetATelecharger);
		String repertoireDeDestination;
		FichierHTML fichierHTML = new FichierHTML(urlPageInternetATelecharger);
		ArrayList<FichierCSS> listeDesFichiersCSSLies;
		ArrayList<String> listeAdresseImages;
		String nomFichierHtml = "index.html";
		int i;
		
		// TRAITEMENTS ---------------------------
		
		System.out.println("Sauvegarde de la page " + urlTextPageInternetATelecharger);
		
		// Création du répertoire de destination de tous les fichiers à téléchager
		if(urlPageInternetATelecharger.toString().endsWith(".html")) {
			i = urlPageInternetATelecharger.toString().lastIndexOf('/');
            nomFichierHtml =  urlPageInternetATelecharger.toString().substring(i + 1);
            urlPageInternetATelecharger =  new URL(urlPageInternetATelecharger.toString().substring(0, i));
		}
		repertoireDeDestination = Arborescence.creerAreborescenceRacineDuTelechargement(urlPageInternetATelecharger.getHost()+urlPageInternetATelecharger.getPath());
		
		
		// TELECHARGER LA PAGE HTML
        // Eregistre le contenu dans un fichier html
		fichierHTML.creerFichierHTML(repertoireDeDestination, nomFichierHtml);
        
        
        // TELECHARGER LES FEUILLES DE STYLE CSS
        // Extraire les adresses des feuilles de styles CSS
        listeDesFichiersCSSLies = fichierHTML.getListeDesFichiersCSSLies();
        // Pour chaque feuille de style CSS liées à la page web
    	for(FichierCSS fichierCSS : listeDesFichiersCSSLies) {
        	// Enrigistrer son contenu dans un fichier css portant le bon nom et avec la bonne arboressance
        	fichierCSS.creerFichierCSS(repertoireDeDestination);
    	}
    	
    	
        // TELECHARGER LES IMAGES
    	// Extraire les adresses des images
    	listeAdresseImages = fichierHTML.getListeAdresseImages();
    	// Télecharger chaque image une à une
    	for(String adressesImage : listeAdresseImages) {
    		Img.telecharge(urlPageInternetATelecharger, repertoireDeDestination, adressesImage);
    	}
    }
    // _______________________________________________________________________________________________________________
    // remove
    // _______________________________________________________________________________________________________________
    private static void supprimeFichierEtRepertoiresParentsVides(File fichierASupprimer) {
        if (fichierASupprimer.delete()) {
            System.out.println("fichier supprimé : " + fichierASupprimer.getPath());
            File parent = fichierASupprimer.getParentFile();
            System.out.println("******parent != null : "+parent != null);
            System.out.println("******parent.isDirectory() : "+parent.isDirectory());
            System.out.println("******parent.list().length : " + parent.list().length);
            while (parent != null && parent.isDirectory() && parent.list().length == 0) {
                if (parent.delete()) {
                    System.out.println("répetoire supprimé : " + parent.getPath());
                    parent = parent.getParentFile();
                } else {
                    break;
                }
            }
        } else {
            System.err.println("Échec de la suppression du fichier : " + fichierASupprimer.getPath());
        }
    }
    public void remove(String urlTextPageInternetASuppriemr) throws IOException {
        // TODO: implementer cette methode
    	System.out.println("methode remove");
    	ArrayList<FichierCSS> listeDesFichiersCSSLies;
		ArrayList<String> listeAdresseImages;
		URL url = new URL(urlTextPageInternetASuppriemr);
    	FichierHTML fichierHtmlASupprimer = new FichierHTML(url);
    	String cheminfichierASUppriemr;
    	
    	cheminfichierASUppriemr = Arborescence.getReprtoire("cache") +"/"+ url.getHost() + url.getPath() + ".compresse.bin";
    	WebPagesSaver.supprimeFichierEtRepertoiresParentsVides(new File(cheminfichierASUppriemr));
    	
    	// SUPPRIMER LES FEUILLES DE STYLE CSS
        // Extraire les adresses des feuilles de styles CSS
        listeDesFichiersCSSLies = fichierHtmlASupprimer.getListeDesFichiersCSSLies();
        // Pour chaque feuille de style CSS liées à la page web
    	for(FichierCSS fichierCSS : listeDesFichiersCSSLies) {
        	// Supprimer le fichier CSS
    		cheminfichierASUppriemr = Arborescence.getReprtoire("cache") +"/"+ fichierCSS.getUrl().getHost() + fichierCSS.getUrl().getPath() + ".compresse.bin";
        	WebPagesSaver.supprimeFichierEtRepertoiresParentsVides(new File(cheminfichierASUppriemr));
    	}
    	
        // SUPPRIMER LES IMAGES
    	// Extraire les adresses des images
    	listeAdresseImages = fichierHtmlASupprimer.getListeAdresseImages();
    	// Supprimer chaque image une à une
    	for(String adressesImage : listeAdresseImages) {
    		WebPagesSaver.supprimeFichierEtRepertoiresParentsVides(new File(Arborescence.getReprtoire("cache") + "/"+ url.getHost() + "/" + adressesImage));
    	}
    	System.out.println("Page web : " + urlTextPageInternetASuppriemr + " supprimer.");
    }

    // _______________________________________________________________________________________________________________
    // list
    // _______________________________________________________________________________________________________________
    public static void trouveFichiersDExtentionHtmlCompresseTxt(File repertoire, ArrayList<String> listeDesFichiersDExtentionHtmlCompresseTxt) {
    	/**
         * Méthode récursive pour trouver tous les fichiers index.html.compresse.bin dans un répertoire et ses sous-répertoires.
         * @param repertoire:File => Le répertoire de départ
         * @param listeDesFichiersInderxHtmlCompresseTxt:ArrayListe<String> => La liste pour stocker les chemins trouvés
         */
    	File[] fichiersEnfants;
    	
        // Vérifie si le répertoire de départ est valide et existant
        if (repertoire.exists() && repertoire.isDirectory()) {
            // Récupère tous les fichiers et répertoires dans le répertoire courant
            fichiersEnfants = repertoire.listFiles();
            if (fichiersEnfants != null) {
                for (File fichierEnfant : fichiersEnfants) {
                    // Si c'est un répertoire, appel récursif pour parcourir ses sous-répertoires
                    if (fichierEnfant.isDirectory()) {
                    	trouveFichiersDExtentionHtmlCompresseTxt(fichierEnfant, listeDesFichiersDExtentionHtmlCompresseTxt);
                    } 
                    // Si c'est un fichier nommé index.html, ajouter son chemin absolu à la liste
                    else if (fichierEnfant.isFile() && fichierEnfant.getName().contains(".html.compresse.bin")) {
                    	listeDesFichiersDExtentionHtmlCompresseTxt.add(fichierEnfant.toPath().toString());
                    }
                }
            }
        }
    }
    public String list() {
    	/**
    	 * Methode qui crée le contenu d'une page html referenceant tous les liens ver une page html qui a été téléchrgée et compressé avec webpagessaver
    	 * @return String =>le contenu de la page html list
    	 */
    	System.out.println("methode list");
    	
    	// DECLARATION DES VARIABLES -------------
    	// Répertoire de départ
        File dossierCache = Arborescence.getReprtoire("cache");
        
        // Liste pour stocker les chemins trouvés
        ArrayList<String> listeTelechargementSauvegardes = new ArrayList<String>();
        
		// chemin du fichier ou dans lequel on soihaite enregistrer la page d'affichage de la liste de l'enssemble des téléchargements enregistrés :
		StringBuilder contenuPageListHtml = null;
		String nomFichier;
		
		// TRAITEMENTS ---------------------------

		// Récupération de la liste des chemins apsoluts de chaque téléchargements enregistrés dans le dossier cache
		// Appeler la fonction récursive pour trouver les fichiers index.html.compress.bin
		trouveFichiersDExtentionHtmlCompresseTxt(dossierCache, listeTelechargementSauvegardes);

        // Génération du contenu de la page HTML
		contenuPageListHtml = new StringBuilder();
		contenuPageListHtml.append("<!DOCTYPE html>\n"
				+ "<html lang=\"fr\">\n"
				+ "    <head>\n"
				+ "        <title>Web Page Saver</title>\n"
				+ "        <meta charset=\"utf-8\">\n"
				+ "        <style>\n"
				+ "            body {\n"
				+ "                min-block-size: 100vh;\n"
				+ "                padding: auto;\n"
				+ "                text-align: center;\n"
				+ "                font-family: sans-serif;\n"
				+ "                font-size: 1.4rem;\n"
				+ "                color: rgb(30, 0, 85);\n"
				+ "                background: linear-gradient(\n"
				+ "                    120deg,\n"
				+ "                    rgb(100, 17, 209),\n"
				+ "                    rgb(255, 0, 0)\n"
				+ "                );\n"
				+ "            }\n"
				+ "\n"
				+ "            header {\n"
				+ "                display: inline-block;\n"
				+ "                max-width: 40rem;\n"
				+ "                margin: 4rem auto;\n"
				+ "                font-size: 3rem;\n"
				+ "                color: hsl(0deg 100% 95%);\n"
				+ "                text-align: center;\n"
				+ "            }\n"
				+ "\n"
				+ "            h1 {\n"
				+ "                line-height: 4.7rem;\n"
				+ "                margin: 0;\n"
				+ "            }\n"
				+ "\n"
				+ "            h2 {\n"
				+ "                display: inline-block;\n"
				+ "                padding: 0.5rem;\n"
				+ "                margin: 0;\n"
				+ "                font-size: 0.5em;\n"
				+ "                color: rgb(75, 0, 0);\n"
				+ "                background: rgba(255, 255, 255, 0.4);\n"
				+ "                border-radius: 10px;\n"
				+ "            }\n"
				+ "\n"
				+ "            main {\n"
				+ "                display: block;\n"
				+ "                text-align: center;\n"
				+ "                margin: 2rem auto;\n"
				+ "            }\n"
				+ "\n"
				+ "            h3 {\n"
				+ "                display: inline-block;\n"
				+ "                margin: 3rem 4rem;\n"
				+ "                margin-top: 0;\n"
				+ "                color: hsl(0 100% 85%);\n"
				+ "            }\n"
				+ "\n"
				+ "            a {\n"
				+ "                display: block;\n"
				+ "                position: relative;\n"
				+ "                margin: 2rem auto;\n"
				+ "                max-width: 40rem;\n"
				+ "                padding: 1rem;\n"
				+ "                background-image: linear-gradient(\n"
				+ "                    to top left,\n"
				+ "                    rgb(187, 135, 255),\n"
				+ "                    rgb(255, 255, 255)\n"
				+ "                );\n"
				+ "                border: 1px solid hsl(260deg 100% 95%);\n"
				+ "                border-radius: 0.3rem;\n"
				+ "                font-weight: 700;\n"
				+ "                text-decoration: none;\n"
				+ "            }\n"
				+ "\n"
				+ "\n"
				+ "            @media (max-width: 650px) {\n"
				+ "                header {\n"
				+ "                    margin-bottom: 1rem;\n"
				+ "                }\n"
				+ "                h1 {\n"
				+ "                    font-size: 2.5rem;\n"
				+ "                    line-height: 3rem;\n"
				+ "                }\n"
				+ "                h2 {\n"
				+ "                    font-size: 0.8rem;\n"
				+ "                }\n"
				+ "\n"
				+ "                main {\n"
				+ "                    font-size: 0.8rem;\n"
				+ "                }\n"
				+ "                a{\n"
				+ "                    margin: 0.5rem auto;\n"
				+ "                }\n"
				+ "            }\n"
				+ "        </style>\n"
				+ "    </head>\n"
				+ "    <body>\n"
				+ "        <header>\n"
				+ "            <h1>Web Page Saver</h1>\n"
				+ "            <h2>compression de fichiers</h2>\n"
				+ "        </header>\n"
				+ "        <main>\n"
				+ "            <h3>Liste des fichiers téléchargés</h3>");
        for (String chemin : listeTelechargementSauvegardes) {
        	nomFichier = chemin.substring(dossierCache.toPath().toString().length());
        	contenuPageListHtml.append("<a href=\"http://localhost:"+PORT).append(nomFichier).append("\">");
        	contenuPageListHtml.append(nomFichier).append("</a>");
        }
        contenuPageListHtml.append("</main>\n"
        		+ "    </body>\n"
        		+ "</html>");

        return contenuPageListHtml.toString();
    }
    // _______________________________________________________________________________________________________________
    // view
    // _______________________________________________________________________________________________________________
    public void view(String nomDuTelechargementADecompresser) throws IOException {
        String uriString = "http://localhost:" + PORT + "/" + nomDuTelechargementADecompresser;
        System.out.println("Ouverture de la page : " + uriString);
        try {
            Desktop desktop = Desktop.getDesktop();
            desktop.browse(new URI(uriString));
        } catch (IOException | URISyntaxException e) {
            e.printStackTrace();
        }
    }

    }
