package webpagessaver;

import java.io.IOException;
import java.net.URL;


public class FichierCSS extends Fichier{
	// ATTRIBUTS :
	private String adresse = "";

	// CONSTRUCTEUR :
	public FichierCSS(URL urlParent, String adresse) throws IOException {
		super(new URL(urlParent, adresse));
		this.adresse = adresse;
	}
	
	
	
	// METHODEs :
	
    public void creerFichierCSS(String repertoireDeDestination) throws IOException {
    	/**
    	 * Méthode qui créer un fichier css du nom correspondant à celui de l'adresse de l'instance de FichierCSS avec l'arboressance correspondante à cette adresse, et écrit le contenu de cette instance à l'intérrieure
    	 */
    	// CREER L'ARBORESSANCE
    	Arborescence.creer(repertoireDeDestination, this.adresse);
        
    	super.creerFichierCompresse(repertoireDeDestination, this.adresse);
    	
    	System.out.println("Feuille CSS \"" + this.adresse + "\" téléchargée.");
    }
}
