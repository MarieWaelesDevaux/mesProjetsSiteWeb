package webpagessaver;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FichierHTML extends Fichier{
	// ATTRIBUTS :
	private ArrayList<FichierCSS> listeDesFichiersCSSLies = new ArrayList<FichierCSS>();
	private ArrayList<String> listeAdresseImages = new ArrayList<String>();
	
	// CONSTRUCTEUR :
	public FichierHTML(URL url) throws IOException {
		super(url);
		this.corrigerLesLienQuiSontEnCheminApsolu();
		this.chercheEtEnregisteLaListeDesFichiersCSSLies();
		this.extraitAdresseDesImages();
	}
	
	// GETTEURS (accesseurs) :
    public ArrayList<FichierCSS> getListeDesFichiersCSSLies() {
		return listeDesFichiersCSSLies;
	}
	public ArrayList<String> getListeAdresseImages() {
		return listeAdresseImages;
	}

	
	// METHODES :	
	// Pour la création du fichier HTML
	
	private void corrigerLesLienQuiSontEnCheminApsolu() {
		/**
    	 * Méthode qui vérifie que les lien qui relie les feuilles de styles css et les images ne soient pas en écrits en chemin apsuluts et si c'est le cas qui retire le / au début
    	 */	
        // Pattern pour href
        Pattern patternHref = Pattern.compile("href=\"(/[^\"]+)\"");
        Matcher matcherHref = patternHref.matcher(super.contenu);
        super.contenu = matcherHref.replaceAll(mr -> "href=\"" + mr.group(1).substring(1) + "\"");

        // Pattern pour src
        Pattern patternSrc = Pattern.compile("src=\"(/[^\"]+)\"");
        Matcher matcherSrc = patternSrc.matcher(super.contenu);
        super.contenu = matcherSrc.replaceAll(mr -> "src=\"" + mr.group(1).substring(1) + "\"");
    }
	public void creerFichierHTML(String repertoireDeDestination, String nomFichierHtml) throws IOException {
    	/**
    	 * Méthode qui créer un fichier "index.html" et écrit le contenu de l'instance de FichierHTML à l'intérrieure
    	 */		
    	super.creerFichierCompresse(repertoireDeDestination, nomFichierHtml);
    	System.out.println("Fichier HTML \"" + super.getUrl().toString() + "\" téléchargée.");
    }
    
	
	// Pour le téléchagement des fichiers liés :
	
	private void chercheEtEnregisteLaListeDesFichiersSelonLePatherne(Pattern pattern, Character typeDeFichier) throws IOException {
    	/**
    	 * Methode qui cherche les liens de cette page web avec les fauilles de styles CSS ou Images afin d'enregistrer la liste des instances de FichierCSS correspondantes ou des adresses des Images
    	 * @param pattern:Pattern -> paterne de la balise <link> à rechercher
    	 * @param typeDeFichier:Character ->  caractère 'C' ou 'I' condant soit à "Fauille de stryle CSS" soit à "Image"
    	 */
    	// comparateur avec le paterne :
        Matcher matcher = pattern.matcher(this.contenu);
        String adresseFichier;
        URL urlParent = super.getUrl();

        // Tant qu'on trouve des balises de liens vers des fichiers de type T (feuilles de style css ou images) non analysées :
        while (matcher.find()) {
        	// extraire la valeure de l'attribut recherché
        	switch (typeDeFichier) {
        	case 'C' :
        		// crer et enregistrer l'instance de FichierCSS correspondante
        		adresseFichier = extraitAdresse(matcher.group(), "href");
        		// Décodez les entités HTML dans l'URL
        		adresseFichier = adresseFichier.replaceAll("&amp;", "&");
        		break;
        	case 'I' :
        		// enregistrer l'adresse de l'immage
        		adresseFichier = extraitAdresse(matcher.group(), "src");
        		// Décodez les entités HTML dans l'URL
        		adresseFichier = adresseFichier.replaceAll("&amp;", "&");
        		break;
        	default :
        		adresseFichier = null;
        	}
            if (adresseFichier != null) {
            	// TODO:
            	// si le fichier est un fichier en ligne commanceant donc par http...
            	/*if (adresseFichier.startsWith("http")) {
        			URL url = new URL(adresseFichier);
        			adresseFichier = url.getHost() + url.getPath();
        			// Modifier le lien dans la balise de la page HTML pour prendre la nouvelle valeur de adresseFichier
        		    super.contenu = super.contenu.replace(matcher.group(), adresseFichier);
        		}*/
            	// Si l'adresse commence par un / et donc qu'il faut chercher le document à la racine de l'hote
            	if(adresseFichier.startsWith("/", 0)){
            		urlParent = new URL(super.getUrl().getHost());
            		//TODO : supprimer le / du lien de la balise html et supprimer la méthode : corrigerLesLienQuiSontEnCheminApsolu
            		/*System.out.println("+++++"+matcher.group());
            		super.contenu = super.contenu.replace(matcher.group(), adresseFichier.substring(1));*/
            	}
            	System.out.println("+***+"+matcher.group());
            	switch (typeDeFichier) {
            	case 'C' :
            		// crer et enregistrer l'instance de FichierCSS correspondante
            		listeDesFichiersCSSLies.add(new FichierCSS(urlParent, adresseFichier));
            		break;
            	case 'I' :
            		// enregistrer l'adresse de l'immage
            		listeAdresseImages.add(adresseFichier);
            		break;
            	}
            }
            else {
                System.err.println("Eurreur : lien à un fichier introuvable.");
            }
        }
    }
    private static String extraitAdresse(String baliseLink, String attribut) {
    	/**
    	 * Methode qui extrait la valeure de l'attribut href de la balise <link>
    	 */
    	// paterne du contenu à l'interrieure des guillement de l'attribut :
        Pattern pattern = Pattern.compile(attribut+"=\"([^\"]+)\"");
        // comparateur avec le patern :
        Matcher matcher = pattern.matcher(baliseLink);
        if (matcher.find()) {
        	// revoyé le contenu des guillements
            return matcher.group(1);
        }
        System.err.println("Erreur: impossible d'extraire la valeure de l'attribut " + attribut + ".");
        return null;
    }
    
	
	// Pour la création des feuilles de styles css
    private void chercheEtEnregisteLaListeDesFichiersCSSLies() throws IOException {
    	/**
    	 * Methode qui cherche les liens de cette page web avec les fauilles de styles CSS afin d'enregistrer la liste des instances de FichierCSS correspondants
    	 */
    	// paterne des balises <link> des feuilles de style css :
    	Pattern pattern = Pattern.compile("<link[^>]*rel\s*=\s*\"stylesheet\"[^>]*>", Pattern.CASE_INSENSITIVE);
    	this.chercheEtEnregisteLaListeDesFichiersSelonLePatherne(pattern, 'C');
    }
    // Pour le téléchargement des images    
    private void extraitAdresseDesImages() throws IOException {
    	/**
    	 * Methode qui cherche les liens de cette page web avec les images afin d'enregistrer la liste de leur adresse
    	 */
    	// paterne des balises <link> des images :
    	Pattern pattern = Pattern.compile("<img[^>]*src\s*=\s*\"([^\"]+)\"[^>]*>", Pattern.CASE_INSENSITIVE);
        this.chercheEtEnregisteLaListeDesFichiersSelonLePatherne(pattern, 'I');
    }
 
}
