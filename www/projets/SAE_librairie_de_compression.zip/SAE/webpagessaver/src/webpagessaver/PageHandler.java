package webpagessaver;

import java.io.IOException;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;


class PageHandler implements HttpHandler {
	/**
	 * Classe qui crée un thread de lecture des requettes envoyées au serveur
	 */
    private final WebPagesSaver WEBPABESSAVER;
    
    public PageHandler(WebPagesSaver webPagesSaver) {
        this.WEBPABESSAVER = webPagesSaver;
    }
    @Override
    public void handle(HttpExchange messageRecu) throws IOException {
    	Thread thread = new Thread(new RequestHandler(messageRecu, WEBPABESSAVER));
        thread.start();
    }

}