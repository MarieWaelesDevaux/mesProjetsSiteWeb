package webpagessaver;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import webcompresslib.ArbreBinaire;


public class Fichier {
	// ATTRIBUTS :
	private URL url = null;
	protected String contenu = "";
	
	// CONSTRUCTEUR :
	protected Fichier(URL url) throws IOException {
		this.url = url;
		this.recupereContenu();
	}
	
	// GETTEURS (accesseurs) :
	protected URL getUrl() {
		return this.url;
	}

	
	// METHODES :
	
    private void recupereContenu() throws IOException{
    	/**
    	 * Méthode qui récupère le contenu de la page HTLM dont le lien est fourni en paramettres
    	 */
        HttpURLConnection connection = null;
        BufferedReader reader = null;
        String ligne;
        
        try {
        	// Ouvrir une connection avec l'url
            connection = (HttpURLConnection) this.url.openConnection();
            connection.setRequestMethod("GET");
            // Si la connexion a été établie avec succès
            if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
            	// Lire le contenu ligne par ligne et l'ajoutter à la variable contenu
                reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                while ((ligne = reader.readLine()) != null) {
                	this.contenu+=ligne;
                }
                reader.close();
                // Si le fichier est vide
                if (contenu.isEmpty()) {
                    System.err.println("Erreur: le fichier\"" + this.url.toString() + "\"  est vide.");
                }
            } else {
                throw new IOException("La connection avec \"" + this.url.toString() + "\" a échouée. Code d'éreure : " + connection.getResponseCode());
            }
            connection.disconnect();
        }
        catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }
    
    public static int indiceDeFinDuDictionnaire(String contenuCompresse) {
    	// rechercher la premiere occurence de la chaine "0}" ou "1}"
        Pattern pattern = Pattern.compile("[01]}");
        Matcher matcher = pattern.matcher(contenuCompresse);

        if (matcher.find()) {
            return matcher.start() + 1; // Retourne l'indice de l'accolade fermante
        }
        return -1; // Retourne -1 si aucune occurrence n'est trouvée
    }
	protected void creerFichierCompresse(String repertoireDeDestination, String nomDuFichier) throws IOException {
    	/**
    	 * Méthode qui créer un fichier du nom passé en paramettre et écrit le contenu compressé de l'instance de Fichier à l'intérrieure
    	 * @param repertoireDeDestination:String -> chemin apsolu du repertoire dans lequel il faut créer le fichier
    	 * @param nomDuFichier:String -> nom du fichier à créer
    	 */		
		// créer le fichier :
    	File fichier = new File(repertoireDeDestination, nomDuFichier+".compresse.bin");
    	FileOutputStream fichierPourEcriture = null;
    	BufferedOutputStream  writer = null;
    	String contenuCompresse;
    	int nombreDOctets;
    	int indiceAcoladeFermante;
    	String dictionnaire;
        String chaineDeBitsbits;
    	byte[] contenuCompresseEnBits = null;
    	byte[] masque_pour_bits_sur_lequel_faire_l_operateur_ou = {
    			(byte) 0b10000000,
                (byte) 0b01000000,
                (byte) 0b00100000,
                (byte) 0b00010000,
                (byte) 0b00001000,
                (byte) 0b00000100,
                (byte) 0b00000010,
                (byte) 0b00000001
    	};
    			
    	
    	// compresser le contenu
    	ArbreBinaire arbreBinaireCorrespondantAuTexte = new ArbreBinaire(this.contenu);
    	contenuCompresse = arbreBinaireCorrespondantAuTexte.encode(this.contenu);
    	indiceAcoladeFermante = Fichier.indiceDeFinDuDictionnaire(contenuCompresse);
    	dictionnaire = contenuCompresse.substring(0, indiceAcoladeFermante + 1);
    	chaineDeBitsbits = contenuCompresse.substring(indiceAcoladeFermante + 1);
    	
        // convertir le string en bits (qui est le contenu compressé)
    	nombreDOctets = (chaineDeBitsbits.length() + 7) / 8;  // Divise par 8 en arondissant au supérieur
    	contenuCompresseEnBits = new byte[nombreDOctets]; // initialiser tout à 0
    	// Parcourir chaque bit de la chaîne de bits
        for (int i = 0; i < chaineDeBitsbits.length() ; i++) {
            // Si le bit actuel est '1', on le place dans le bon emplacement du tableau d'octets
            if (chaineDeBitsbits.charAt(i) == '1') {
                // Utilisation du masque pour définir le bit correct dans l'octet
            	contenuCompresseEnBits[i / 8] |= masque_pour_bits_sur_lequel_faire_l_operateur_ou[i % 8]; // effectuer l'opérateur OU bits à bits
            }
        }
    	
        
        
        try {
        	// Ouverir le fichier pour l'écriture
        	fichierPourEcriture = new FileOutputStream(fichier);
            // ouvrir la mémoire tampon d'écriture du fichier
            writer = new BufferedOutputStream(fichierPourEcriture);
            
            // Écrire le dictionnaire comme une chaîne de caractères
            writer.write(dictionnaire.getBytes(StandardCharsets.UTF_8));
            
            // écrir le contenu rentré en paramettre dans le fichier
            writer.write(contenuCompresseEnBits);
            
            // fermer le fichier et la mémoire tampon
            writer.flush();
            writer.close();
            fichierPourEcriture.close();
        }
        catch (IOException e) {
            System.err.println("Erreur d'écriture dans le fichier \"" + fichier + "\" : " + e.getMessage());
        }
    }
}
